# Entregables del Seminario de Inteligencia Artificial

**Autor:** Camilo Cepeda Orduz  
**Institución:** Fundación de Educación Superior San José  
**Período:** 2026-2

## Contenido

- `00_Ensayo/`: ensayo actualizado conforme a APA 7, editable en DOCX y exportado a PDF.
- `01_Proyecto_Tecnico/`: E1–E7, datos de práctica, ETL y proyecto Power BI.
- `01_Proyecto_Tecnico/05_MOCKUPS_FIGMA_IMPORTABLE/`: tres maquetas vectoriales en SVG, variables de estilo y una guía para importarlas en Figma. El PDF de diseño acompaña las vistas.
- `01_Proyecto_Tecnico/07_ENTREGABLE_7_ACTUALIZADO/`: documentación, diccionario, presentación, guía de instalación y archivo nativo `.fig`.

## Abrir el tablero

Se incluyen el proyecto editable `06_DASHBOARD.pbip` y el archivo `06_DASHBOARD.pbix`, con tres páginas. Para abrir el PBIP, ejecute `CONFIGURAR_DASHBOARD.ps1` desde `01_Proyecto_Tecnico/`, abra `06_DASHBOARD.pbip` en Power BI Desktop y actualice el modelo. El PBIX se puede abrir directamente en Power BI Desktop.

## Alcance de la evidencia

Los registros son sintéticos y se usan con fines académicos. No describen ni estiman una empresa real. El entregable 7 incluye la presentación y el guion de apoyo para el video de cinco minutos; el ZIP no contiene la grabación del tutorial, que sigue pendiente.

"""
ENTREGABLE 4 - PIPELINE ETL
Proyecto: Dashboard de Liquidacion y Facturacion de Servicios de Transporte Especial

QUE HACE
    Toma los tres archivos crudos del proceso de liquidacion, los limpia, valida su
    integridad, calcula los indicadores y deja en disco los archivos limpios que
    alimentan el tablero.

    EXTRACT    Lee tres fuentes: Excel de cabeceras, CSV de items, CSV de historial.
    TRANSFORM  Normaliza formatos, deduplica, recalcula y marca valores atipicos.
    VALIDATE   Ejecuta siete comprobaciones de integridad sobre el resultado.
    LOAD       Escribe cuatro archivos limpios listos para la herramienta de tablero.

COMO SE EJECUTA
    python 04_PIPELINE.py

    Sin argumentos. Lee de 00_DATOS/raw/ y escribe en 00_DATOS/limpio/.
    Cada ejecucion deja una bitacora en 00_DATOS/logs/pipeline.log.

AUTOMATIZACION (opcional)
    El proceso esta pensado para correr una vez al mes, despues del cierre del periodo.
    En Windows se programa con el Programador de tareas; en macOS o Linux, con cron:
        0 6 1 * *  cd /ruta/al/proyecto && python 04_PIPELINE.py
"""

import logging
import re
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
RAW = BASE / "00_DATOS" / "raw"
LIMPIO = BASE / "00_DATOS" / "limpio"
LOGS = BASE / "00_DATOS" / "logs"

ESTADOS_VALIDOS = ["BORRADOR", "LIQUIDADA", "APROBADA", "FACTURADA", "ANULADA"]
TIPOS_VALIDOS = ["HORA_24", "HORA_12", "HORA", "KILOMETRO"]
TOLERANCIA_DESCUADRE = 0.01          # 1% de diferencia admitida entre cabecera y detalle


# ══════════════════════════════════════════════════════════════════════
# BITACORA
# ══════════════════════════════════════════════════════════════════════

def configurar_log():
    """Deja registro en archivo y en consola de todo lo que hace el proceso."""
    LOGS.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(LOGS / "pipeline.log", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )
    return logging.getLogger("pipeline")


log = configurar_log()


# ══════════════════════════════════════════════════════════════════════
# 1. EXTRACT
# ══════════════════════════════════════════════════════════════════════

def extraer():
    """Carga las tres fuentes crudas sin transformar nada todavia."""
    log.info("=" * 62)
    log.info("EXTRACT - lectura de fuentes")

    cabecera = pd.read_excel(RAW / "liquidaciones_cabecera.xlsx")
    items = pd.read_csv(RAW / "liquidaciones_items.csv", dtype=str)
    historial = pd.read_csv(RAW / "historial_estados.csv")

    log.info("  cabecera  : %6d filas  (%s)", len(cabecera), "Excel")
    log.info("  items     : %6d filas  (%s)", len(items), "CSV")
    log.info("  historial : %6d filas  (%s)", len(historial), "CSV")
    return cabecera, items, historial


# ══════════════════════════════════════════════════════════════════════
# 2. TRANSFORM
# ══════════════════════════════════════════════════════════════════════

def a_numero(valor):
    """
    Convierte a numero un campo que puede venir como numero o como texto con
    formato de moneda colombiana ('$452.000').
    """
    if pd.isna(valor):
        return np.nan
    texto = str(valor).strip().replace("$", "").replace(" ", "")
    if "." in texto and "," not in texto and len(texto.split(".")[-1]) == 3:
        texto = texto.replace(".", "")          # separador de miles, no decimal
    texto = texto.replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        return np.nan


def a_fecha(valor):
    """Interpreta fechas que llegan en dos formatos distintos del mismo export."""
    if pd.isna(valor):
        return pd.NaT
    texto = str(valor).strip()
    for formato in ("%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return pd.to_datetime(texto, format=formato)
        except (ValueError, TypeError):
            continue
    return pd.to_datetime(texto, errors="coerce", dayfirst=True)


def normalizar_placa(valor):
    """Lleva cualquier variante de escritura al formato de catalogo VEH-000."""
    if pd.isna(valor):
        return np.nan
    limpio = re.sub(r"[^A-Za-z0-9]", "", str(valor)).upper()
    encontrado = re.match(r"^VEH(\d+)$", limpio)
    return f"VEH-{int(encontrado.group(1)):03d}" if encontrado else limpio


def limpiar_cabecera(df):
    """Normaliza la cabecera y deriva los campos de tiempo del proceso."""
    log.info("TRANSFORM - cabecera")
    antes = len(df)

    # La operadora viene de un campo de texto libre con cuatro escrituras distintas
    df["operadora"] = (df["operadora"].astype(str).str.strip().str.upper()
                       .str.replace(r"\s+", "-", regex=True))
    log.info("  operadora normalizada a %d valores de catalogo",
             df["operadora"].nunique())

    df["cliente"] = df["cliente"].astype(str).str.strip().str.upper()
    df["estado"] = df["estado"].astype(str).str.strip().str.upper()

    for col in ["fecha_liquidacion", "fecha_aprobacion", "fecha_facturacion"]:
        df[col] = df[col].apply(a_fecha)

    df = df.drop_duplicates(subset=["consecutivo"])
    if antes != len(df):
        log.info("  %d cabeceras duplicadas eliminadas", antes - len(df))

    # Campos derivados que el tablero necesita
    df["periodo"] = pd.to_datetime(dict(year=df["anio"], month=df["mes"], day=1))
    df["dias_a_facturacion"] = (df["fecha_facturacion"] - df["fecha_liquidacion"]).dt.days
    df["dias_a_aprobacion"] = (df["fecha_aprobacion"] - df["fecha_liquidacion"]).dt.days
    df["es_anulada"] = df["estado"] == "ANULADA"
    df["es_facturada"] = df["estado"] == "FACTURADA"
    df["observaciones"] = df["observaciones"].fillna("").astype(str).str.strip()

    log.info("  %d liquidaciones listas", len(df))
    return df


def limpiar_items(df, consecutivos_validos):
    """Normaliza el detalle: tipos, formatos, duplicados y referencias."""
    log.info("TRANSFORM - items")
    inicial = len(df)

    # Duplicados exactos por doble carga del archivo
    df = df.drop_duplicates()
    log.info("  %d filas duplicadas eliminadas", inicial - len(df))

    # Referencias a liquidaciones que no existen
    antes = len(df)
    df = df[df["consecutivo"].isin(consecutivos_validos)]
    log.info("  %d items huerfanos descartados", antes - len(df))

    df["placa"] = df["placa"].apply(normalizar_placa)
    df["recorrido"] = df["recorrido"].astype(str).str.strip().str.upper()
    df["tipo_servicio"] = df["tipo_servicio"].astype(str).str.strip().str.upper()

    for col in ["cantidad", "valor_unitario", "porcentaje_descuento",
                "cantidad_pernoctes", "valor_pernocte_unitario"]:
        df[col] = df[col].apply(a_numero)

    for col in ["fecha_inicial", "fecha_final"]:
        df[col] = df[col].apply(a_fecha)

    # La planilla vacia no se inventa: se marca, porque afecta la trazabilidad
    df["numero_planilla"] = df["numero_planilla"].fillna("").astype(str).str.strip()
    df["tiene_planilla"] = df["numero_planilla"] != ""
    log.info("  %d items sin numero de planilla (%.1f%%)",
             (~df["tiene_planilla"]).sum(), (~df["tiene_planilla"]).mean() * 100)

    # Item sin tercero significa flota propia, no es un dato faltante
    df["tercero"] = df["tercero"].fillna("").astype(str).str.strip()
    df["es_tercero"] = df["tercero"] != ""

    # Los importes se recalculan a partir de los valores ya limpios
    df["subtotal"] = (df["cantidad"] * df["valor_unitario"]).round(2)
    df["valor_final"] = (df["subtotal"] * (1 - df["porcentaje_descuento"] / 100)).round(2)
    df["valor_pernoctes_total"] = (df["cantidad_pernoctes"]
                                   * df["valor_pernocte_unitario"]).round(2)

    df = df.dropna(subset=["cantidad", "valor_unitario"])
    log.info("  %d items listos", len(df))
    return df.reset_index(drop=True)


def detectar_anomalias(df):
    """
    Marca los items cuyo valor unitario o cantidad se sale del comportamiento
    esperado para su tipo de tarifa.

    Metodo: rango intercuartilico (Tukey). Para cada tipo de servicio se calculan
    el primer y el tercer cuartil, y se considera atipico todo lo que quede a mas
    de 1,5 rangos intercuartilicos de esos limites.

    Es un criterio estadistico simple, explicable y reproducible. En un proceso que
    termina en una factura, poder justificar por que se marco un registro importa
    mas que la sofisticacion del metodo.
    """
    log.info("TRANSFORM - deteccion de valores atipicos (rango intercuartilico)")
    df["es_anomalia"] = False
    df["motivo_anomalia"] = ""

    for tipo in df["tipo_servicio"].unique():
        mascara_tipo = df["tipo_servicio"] == tipo
        for columna, etiqueta in [("valor_unitario", "tarifa"), ("cantidad", "cantidad")]:
            serie = df.loc[mascara_tipo, columna]
            q1, q3 = serie.quantile(0.25), serie.quantile(0.75)
            rango = q3 - q1
            limite_inf, limite_sup = q1 - 1.5 * rango, q3 + 1.5 * rango

            fuera = mascara_tipo & ((df[columna] < limite_inf) | (df[columna] > limite_sup))
            df.loc[fuera, "es_anomalia"] = True
            df.loc[fuera, "motivo_anomalia"] = (
                df.loc[fuera, "motivo_anomalia"]
                .str.cat([f"{etiqueta} fuera de rango"] * fuera.sum(), sep="; ").str.strip("; ")
            )

    total = int(df["es_anomalia"].sum())
    log.info("  %d items marcados como atipicos (%.2f%%)", total, total / len(df) * 100)
    return df


def calcular_tiempos(historial):
    """Mide cuantos dias tarda cada transicion del flujo de aprobacion."""
    log.info("TRANSFORM - tiempos del proceso")
    historial["fecha"] = historial["fecha"].apply(a_fecha)
    historial = historial.sort_values(["consecutivo", "fecha"])
    historial["fecha_anterior"] = historial.groupby("consecutivo")["fecha"].shift(1)
    historial["dias_en_etapa"] = (historial["fecha"]
                                  - historial["fecha_anterior"]).dt.days
    historial["transicion"] = (historial["estado_anterior"].fillna("INICIO")
                               + " -> " + historial["estado_nuevo"])
    log.info("  %d transiciones medidas", historial["dias_en_etapa"].notna().sum())
    return historial


def calcular_kpis(cabecera, items):
    """
    Consolida los doce indicadores del proyecto por periodo y operadora.
    Las liquidaciones anuladas se excluyen de los ingresos y se reportan aparte.
    """
    log.info("TRANSFORM - calculo de indicadores")

    vigentes = cabecera[~cabecera["es_anulada"]]
    items_vigentes = items[items["consecutivo"].isin(vigentes["consecutivo"])]

    # Agregados de la cabecera
    base = vigentes.groupby(["periodo", "operadora"]).agg(
        valor_liquidado=("total", "sum"),
        valor_facturado=("total", lambda s: s[vigentes.loc[s.index, "es_facturada"]].sum()),
        n_liquidaciones=("consecutivo", "count"),
        ticket_promedio=("total", "mean"),
        valor_servicios=("valor_servicios", "sum"),
        valor_recargos=("valor_recargos", "sum"),
        valor_transporte_adicional=("valor_transporte_adicional", "sum"),
        valor_pernoctes=("valor_pernoctes", "sum"),
        dias_a_facturacion=("dias_a_facturacion", "mean"),
    ).reset_index()

    # Participacion de cada concepto sobre el ingreso del periodo
    base["pct_recargos"] = (base["valor_recargos"] / base["valor_servicios"] * 100).round(2)
    base["pct_transporte_adicional"] = (base["valor_transporte_adicional"]
                                        / base["valor_servicios"] * 100).round(2)

    # Tasa de anulacion sobre el total emitido en el periodo
    anulaciones = cabecera.groupby(["periodo", "operadora"]).agg(
        n_total=("consecutivo", "count"),
        n_anuladas=("es_anulada", "sum"),
    ).reset_index()
    anulaciones["tasa_anulacion"] = (anulaciones["n_anuladas"]
                                     / anulaciones["n_total"] * 100).round(2)

    # Agregados del detalle
    detalle = items_vigentes.merge(
        vigentes[["consecutivo", "periodo", "operadora"]], on="consecutivo", how="left"
    )
    por_detalle = detalle.groupby(["periodo", "operadora"]).agg(
        descuento_promedio=("porcentaje_descuento", "mean"),
        n_items=("consecutivo", "count"),
        valor_terceros=("valor_final", lambda s: s[detalle.loc[s.index, "es_tercero"]].sum()),
        valor_items=("valor_final", "sum"),
        n_anomalias=("es_anomalia", "sum"),
    ).reset_index()
    por_detalle["pct_terceros"] = (por_detalle["valor_terceros"]
                                   / por_detalle["valor_items"] * 100).round(2)

    kpis = (base.merge(anulaciones[["periodo", "operadora", "tasa_anulacion", "n_anuladas"]],
                       on=["periodo", "operadora"], how="left")
                .merge(por_detalle, on=["periodo", "operadora"], how="left"))

    for col in kpis.select_dtypes("float").columns:
        kpis[col] = kpis[col].round(2)

    log.info("  %d filas de indicadores (periodo x operadora)", len(kpis))
    return kpis


# ══════════════════════════════════════════════════════════════════════
# 3. VALIDACION DE INTEGRIDAD
# ══════════════════════════════════════════════════════════════════════

def validar(cabecera, items, kpis):
    """
    Siete comprobaciones sobre el resultado. Una validacion que falla no detiene
    el proceso: se registra, porque el objetivo es detectar y reportar, no ocultar.
    """
    log.info("=" * 62)
    log.info("VALIDACION DE INTEGRIDAD")
    resultados = []

    def check(nombre, condicion, detalle=""):
        estado = "OK  " if condicion else "AVISO"
        log.info("  [%s] %s %s", estado, nombre, detalle)
        resultados.append({"validacion": nombre, "resultado": "OK" if condicion else "AVISO",
                           "detalle": detalle})

    check("Hay liquidaciones cargadas", len(cabecera) > 0, f"{len(cabecera)} filas")
    check("Hay items cargados", len(items) > 0, f"{len(items)} filas")

    check("Consecutivos unicos", cabecera["consecutivo"].is_unique)

    sin_ref = (~items["consecutivo"].isin(cabecera["consecutivo"])).sum()
    check("Todo item referencia una liquidacion", sin_ref == 0, f"{sin_ref} huerfanos")

    estados_raros = set(cabecera["estado"]) - set(ESTADOS_VALIDOS)
    check("Estados dentro del catalogo", not estados_raros, str(estados_raros or ""))

    tipos_raros = set(items["tipo_servicio"]) - set(TIPOS_VALIDOS)
    check("Tipos de servicio dentro del catalogo", not tipos_raros, str(tipos_raros or ""))

    # El total declarado en la cabecera debe cuadrar con la suma del detalle
    suma_items = items.groupby("consecutivo")["valor_final"].sum()
    comparacion = cabecera.set_index("consecutivo")["valor_servicios"].to_frame("declarado")
    comparacion["calculado"] = suma_items
    comparacion = comparacion.dropna()
    comparacion["desvio"] = ((comparacion["declarado"] - comparacion["calculado"]).abs()
                             / comparacion["declarado"].replace(0, np.nan))
    descuadres = int((comparacion["desvio"] > TOLERANCIA_DESCUADRE).sum())
    check("Cabecera cuadra con el detalle", descuadres == 0,
          f"{descuadres} liquidaciones con desvio mayor al {TOLERANCIA_DESCUADRE:.0%}")

    fechas_malas = int((items["fecha_final"] < items["fecha_inicial"]).sum())
    check("Fechas de servicio coherentes", fechas_malas == 0, f"{fechas_malas} invertidas")

    check("Indicadores calculados", len(kpis) > 0, f"{len(kpis)} filas")

    avisos = sum(1 for r in resultados if r["resultado"] == "AVISO")
    log.info("  %d de %d validaciones con aviso", avisos, len(resultados))
    return pd.DataFrame(resultados), comparacion.reset_index()


# ══════════════════════════════════════════════════════════════════════
# 4. LOAD
# ══════════════════════════════════════════════════════════════════════

def cargar(cabecera, items, tiempos, kpis, validaciones):
    """Escribe los archivos limpios que consume la herramienta de tablero."""
    log.info("=" * 62)
    log.info("LOAD - escritura de archivos limpios")
    LIMPIO.mkdir(parents=True, exist_ok=True)

    salidas = {
        "liquidaciones.csv": cabecera,
        "items.csv": items,
        "tiempos_proceso.csv": tiempos,
        "kpis_mensuales.csv": kpis,
        "validaciones.csv": validaciones,
    }
    for nombre, df in salidas.items():
        df.to_csv(LIMPIO / nombre, index=False, encoding="utf-8-sig")
        log.info("  %-24s %6d filas", nombre, len(df))
    return salidas


# ══════════════════════════════════════════════════════════════════════
# ORQUESTACION
# ══════════════════════════════════════════════════════════════════════

def main():
    inicio = datetime.now()
    log.info("")
    log.info("#" * 62)
    log.info("EJECUCION DEL PIPELINE - %s", inicio.strftime("%Y-%m-%d %H:%M:%S"))
    log.info("#" * 62)

    cabecera_raw, items_raw, historial_raw = extraer()

    cabecera = limpiar_cabecera(cabecera_raw)
    items = limpiar_items(items_raw, set(cabecera["consecutivo"]))
    items = detectar_anomalias(items)
    tiempos = calcular_tiempos(historial_raw)
    kpis = calcular_kpis(cabecera, items)

    validaciones, _ = validar(cabecera, items, kpis)
    cargar(cabecera, items, tiempos, kpis, validaciones)

    duracion = (datetime.now() - inicio).total_seconds()
    log.info("=" * 62)
    log.info("PROCESO TERMINADO en %.2f segundos", duracion)
    log.info("")


if __name__ == "__main__":
    main()

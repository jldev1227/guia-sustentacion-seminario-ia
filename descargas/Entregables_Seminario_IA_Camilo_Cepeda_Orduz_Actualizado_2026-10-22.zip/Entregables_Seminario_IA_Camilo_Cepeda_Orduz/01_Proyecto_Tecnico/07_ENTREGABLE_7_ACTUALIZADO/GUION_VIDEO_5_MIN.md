# Guion del video tutorial · LIQUIDA Analytics

**Duración:** 5:00 · **Autor:** Camilo Cepeda Orduz · **Formato de entrega:** MP4 1080p recomendado  
**Estado:** guion listo; falta realizar la grabación y adjuntar el MP4.

> Las cifras del tablero provienen de un conjunto sintético preparado con fines académicos. No representan una empresa real ni deben leerse como saldo vigente, SLA, evidencia de fraude o diagnóstico operacional.

## Guion cronometrado

### 0:00–0:20 · Apertura

**En pantalla:** portada de la presentación; después, cambiar a Power BI Desktop.  
**Narración:** “Hola, soy Camilo Cepeda Orduz. En este video presento LIQUIDA Analytics, un ejercicio académico que conecta preparación de datos, indicadores y un informe interactivo en Power BI para explorar liquidaciones de servicios de transporte especial.”

### 0:20–0:50 · Datos y alcance

**En pantalla:** mostrar brevemente la carpeta `00_DATOS` y luego regresar a Power BI.  
**Narración:** “El conjunto de práctica contiene 134 liquidaciones, 4.448 ítems de detalle y 428 eventos de cambio de estado, entre septiembre de 2024 y agosto de 2026. Los registros son sintéticos. Por eso el objetivo es demostrar el método y la trazabilidad, no describir el comportamiento de una compañía.”

### 0:50–1:25 · Preparación y calidad

**En pantalla:** mostrar `04_PIPELINE.py`, la bitácora y los archivos dentro de `00_DATOS/limpio/`.  
**Narración:** “El pipeline lee las fuentes crudas, normaliza campos, deriva tiempos, agrega los KPI y escribe cinco CSV limpios. La corrida revisada registra nueve controles: ocho OK y un aviso porque una liquidación difiere más de uno por ciento entre cabecera y detalle. El aviso queda visible para revisión; no se descarta ni se interpreta por sí solo como un error confirmado.”

### 1:25–2:20 · Vista 1: Visión ejecutiva

**En pantalla:** seleccionar la pestaña inferior **Visión ejecutiva**; señalar periodo y operadora y recorrer tarjetas, tendencia y composición.  
**Narración:** “Esta página responde cuánto se liquidó y facturó, cómo cambia por mes y qué conceptos forman el subtotal. En este corte, el KPI K01 suma 3.600 millones de pesos en liquidaciones no anuladas. K02 suma 2.020 millones facturados: equivale al 56,1 por ciento del K01 del conjunto, no a un saldo pendiente ni a una promesa de recaudo. El ticket promedio K03 es 27,9 millones. La composición usa subtotal como denominador; los KPI K06 y K07 usan valor de servicios, así que esos porcentajes no se deben comparar directamente.”

### 2:20–3:20 · Vista 2: Detalle operacional

**En pantalla:** seleccionar **Detalle operacional**; mostrar ranking, filtros, tabla y filas con marcas de revisión.  
**Narración:** “La segunda página permite explorar concentración por vehículo, recorrido y tipo de servicio. Los filtros y las selecciones acotan las tablas relacionadas; se puede limpiar la selección para volver al conjunto completo. K08 y K09 ayudan a ordenar el detalle por valor, pero no miden rentabilidad ni utilización de capacidad. En los ítems aparecen 122 marcas estadísticas IQR y 356 registros sin planilla. Una marca prioriza una verificación documental; no confirma error ni fraude, y el pipeline no borra esos datos.”

### 3:20–4:15 · Vista 3: Tiempos y comparativos

**En pantalla:** seleccionar **Tiempos y comparativos**; apuntar a promedios por transición, comparación temporal y filtros.  
**Narración:** “La tercera página separa el ciclo en transiciones. La media observada es 3,1 días de borrador a liquidada, 10,8 de liquidada a aprobada y 4,2 de aprobada a facturada. K05 resume la transición de aprobación; K04 promedia 18,1 días hasta facturación en 75 liquidaciones facturadas que tienen duración registrada. Son promedios descriptivos del conjunto generado, no niveles de servicio ni prueba de un cuello de botella empresarial.”

### 4:15–4:45 · Cómo usar e interpretar

**En pantalla:** cambiar de nuevo entre las tres pestañas; mostrar los filtros y el catálogo `03_KPIs.xlsx`.  
**Narración:** “Para usar el informe, primero seleccione periodo y operadora; luego compare visuales con el mismo filtro y revise la definición del KPI en el catálogo. Las cifras redondeadas pueden variar frente a los CSV. Para reproducirlas prevalecen la fórmula documentada, el modelo del PBIP y los datos limpios. El alcance es descriptivo: no calcula costos ni margen, no predice demoras y no clasifica fraude.”

### 4:45–5:00 · Cierre

**En pantalla:** portada o tercera página del tablero.  
**Narración:** “El proyecto entrega el proceso ETL, el catálogo de doce KPI, el modelo Power BI de tres páginas, la documentación, el diccionario y esta presentación. El aporte es hacer visible cómo cada indicador depende de datos y reglas que pueden revisarse. Gracias.”

## Preparación y lista de comprobación

1. En Windows, abrir `06_DASHBOARD.pbix` en Power BI Desktop y confirmar que carga las tres páginas sin errores. No regenerar ni modificar el dataset durante la grabación.
2. Cerrar notificaciones y ventanas ajenas; maximizar Power BI y dejar visibles los nombres de las pestañas inferiores.
3. Grabar pantalla y voz, con resolución 1920 × 1080 si está disponible. Mantener el cursor sobre cada visual mientras se explica; evitar desplazamientos rápidos.
4. Respetar los cortes de tiempo para una duración total de 5:00. Usar el paquete de diapositivas únicamente para la apertura si el video debe priorizar la demostración en Power BI.
5. Revisar legibilidad, sonido, duración y que no aparezcan datos personales reales. Exportar como `07_VIDEO_TUTORIAL.mp4` y añadirlo a la carpeta actualizada del Entregable 7.

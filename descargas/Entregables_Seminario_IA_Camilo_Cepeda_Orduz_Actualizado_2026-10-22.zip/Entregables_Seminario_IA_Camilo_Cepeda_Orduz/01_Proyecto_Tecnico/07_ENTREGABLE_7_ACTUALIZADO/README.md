# Entregable 7 · LIQUIDA Analytics

Documentación técnica, guía de uso, diccionario de datos y presentación ejecutiva del dashboard Power BI del proyecto de seminario.

**Autor:** Camilo Cepeda Orduz · **Corte:** octubre de 2026 · **Uso:** académico.

> El conjunto es sintético. Los valores, alertas y tiempos que aparecen aquí describen el ejercicio reproducible; no son cifras de una empresa, SLA, diagnóstico de fraude ni recomendación operativa.

## Archivos de esta entrega

| Archivo | Contenido |
|---|---|
| `07_DOCUMENTACION.docx` | Documento técnico de 6 páginas, guía de usuario, interpretación, limitaciones, roadmap y mantenimiento. |
| `07_DICCIONARIO_DATOS.docx` | Diccionario de los cinco CSV limpios y definiciones de los 12 KPI. |
| `07_PRESENTACION.pptx` | Presentación ejecutiva de 14 diapositivas; contiene cinco gráficos editables construidos desde los datos limpios. |
| `05_DISENO_VISUALIZACIONES.pdf` | Especificación visual de 5 páginas para las tres vistas y el sistema de diseño. |
| `05_DISENO_FIGMA.fig` | Copia nativa descargada desde Figma, con los mockups y la organización del archivo compartido. |
| `05_DISENO_FIGMA_IMPORTABLE.zip` | Tres artboards SVG, tokens visuales, guía de importación, PDF de diseño, vista previa y copia `.fig`. |
| `GUION_VIDEO_5_MIN.md` | Guion cronometrado y plan de grabación. El MP4 final todavía debe grabarse. |

## Qué hay implementado

El tablero Power BI tiene tres páginas: **Visión ejecutiva**, **Detalle operacional** y **Tiempos y comparativos**. El proyecto editable está en `06_DASHBOARD.pbip` y la copia lista para abrir en `06_DASHBOARD.pbix`, en la raíz del proyecto técnico. En Power BI Desktop se recomienda abrir el PBIX; para modificar el informe, abrir el PBIP. Ambos requieren Power BI Desktop en Windows.

Los tres SVG incluidos en el ZIP de Figma son mockups vectoriales de esas páginas, no capturas tomadas de Power BI Desktop. La presentación los marca como referencias. Sus gráficos cuantitativos nativos se recalcularon desde los CSV limpios para que las cifras y la explicación se puedan revisar por separado del mockup.

## Abrir y actualizar el proyecto

1. Descomprime o abre la carpeta completa del proyecto técnico; conserva juntos `00_DATOS/`, `04_PIPELINE.py`, `06_DASHBOARD.pbip` y `06_DASHBOARD.pbix`.
2. Instala Python 3.10 o superior y las dependencias: `pip install -r requirements.txt`.
3. Opcionalmente regenera los CSV ejecutando `python 04_PIPELINE.py` desde la raíz del proyecto. El ETL lee `00_DATOS/raw/`, escribe cinco tablas en `00_DATOS/limpio/` y registra la corrida en `00_DATOS/logs/pipeline.log`.
4. En Windows, ejecuta una vez `CONFIGURAR_DASHBOARD.ps1` para la ruta local; abre `06_DASHBOARD.pbix` en Power BI Desktop y selecciona **Actualizar**. Para editar el informe, usa `06_DASHBOARD.pbip`.
5. Compara las tarjetas y filtros con `03_KPIs.xlsx`, `00_DATOS/limpio/` y el diccionario de esta entrega. Las reglas y denominadores están descritos allí.

El pipeline produce nueve controles de calidad: el corte revisado tiene ocho resultados `OK` y un `AVISO` por una diferencia superior al 1% entre cabecera y detalle en un registro. El aviso debe revisarse con el dato de origen; no se oculta ni se interpreta automáticamente como error confirmado.

## Lectura comprobable del conjunto

El corte contiene **134 liquidaciones**, **4.448 ítems** y **428 eventos de estado**, entre septiembre de 2024 y agosto de 2026. Entre los resultados calculados desde los CSV están:

- K01 valor liquidado (no anuladas): **$3.600 millones COP**.
- K02 valor facturado: **$2.020 millones COP**, equivalente al **56,1%** del K01 en este corte sintético.
- K03 ticket promedio por liquidación no anulada: **$27,9 millones COP**.
- K04 ciclo medio hasta facturación: **18,1 días** en 75 liquidaciones facturadas con duración registrada.
- K05 transición liquidada → aprobada: **10,8 días** de promedio en 98 transiciones observadas.
- K10 tasa de anulación: **3,7%** (5 de 134 liquidaciones).
- Revisión de detalle: **122** marcas IQR y **356** ítems sin planilla. Una marca es una señal para revisar, no una conclusión de error o fraude.

La composición mostrada en el gráfico nativo de la presentación usa el **subtotal**: servicio base 81,3%, recargos 7,9%, transporte adicional más administración 4,7% y pernoctes 6,2% (la suma puede variar 0,1 puntos por redondeo). K06 y K07 usan `valor_servicios` como denominador; no son directamente esos porcentajes de composición. Si una visual de mockup difiere, prevalece el recálculo desde CSV y la fórmula documentada.

El conjunto no permite inferir estacionalidad, desempeño, causas, riesgo ni cuellos de botella de una operación real. Los umbrales de referencia en el catálogo KPI son propuestas académicas, no benchmarks validados.

## Importar los mockups en Figma

Descarga `05_DISENO_FIGMA_IMPORTABLE.zip`, descomprímelo y arrastra cada SVG (`01_vision_ejecutiva.svg`, `02_detalle_operacional.svg`, `03_tiempos_comparativos.svg`) a un canvas de Figma. La guía dentro del ZIP explica cómo conservar proporciones y separar las tres vistas; `design-tokens.json` resume los estilos.

También puedes abrir `05_DISENO_FIGMA.fig` directamente en Figma, o importarlo desde el menú de archivo. El ZIP sirve como respaldo portable de las fuentes vectoriales y su especificación.

El archivo de Figma compartido y su prototipo navegable están disponibles en:

- [Abrir el archivo de diseño](https://www.figma.com/design/0DCn9d2JJFMS2nLgepZWt8/LIQUIDA-Analytics-%E2%80%94-Mockups-de-Dashboard)
- [Probar el prototipo de las tres vistas](https://www.figma.com/proto/0DCn9d2JJFMS2nLgepZWt8/LIQUIDA-Analytics-%E2%80%94-Mockups-de-Dashboard?node-id=15-507&scaling=contain&content-scaling=fixed&page-id=15%3A506&starting-point-node-id=15%3A507&show-proto-sidebar=1)

El `.fig` es una copia nativa descargada del archivo compartido. El paquete SVG permite importar las vistas en otro archivo; para abrir el prototipo interactivo usa el enlace en línea.

## Cobertura de Entregable 7

- Documentación técnica (6 páginas), guía de usuario, 12 KPI, limitaciones, roadmap y mantenimiento: **listo**.
- Diccionario de campos y fórmulas KPI: **listo**.
- Presentación ejecutiva (14 diapositivas): **lista**.
- README de instalación y actualización: **listo**.
- Diseño de visualizaciones y mockups importables en Figma: **listo**.
- Video tutorial de 5 minutos: **guion listo; falta grabar y adjuntar el MP4**.

La grabación MP4 es el único elemento pendiente de cierre.

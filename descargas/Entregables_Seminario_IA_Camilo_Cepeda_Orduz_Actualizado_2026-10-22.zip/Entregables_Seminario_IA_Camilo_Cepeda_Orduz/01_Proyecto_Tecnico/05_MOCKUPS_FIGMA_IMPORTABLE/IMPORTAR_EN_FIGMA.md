# Mockups vectoriales y archivo Figma · LIQUIDA Analytics

La carpeta contiene tres artboards de escritorio de 1440 × 900 px en formato SVG:

- `01_vision_ejecutiva.svg`
- `02_detalle_operacional.svg`
- `03_tiempos_comparativos.svg`

Para importar las vistas en otro diseño, arrastra cada SVG a un canvas de Figma. Se incorporan como vectores para inspeccionar y editar sus elementos. `design-tokens.json` resume estilos y `../05_DISENO_VISUALIZACIONES.pdf` contiene la guía visual de cinco páginas.

El archivo nativo descargable `../05_DISENO_FIGMA.fig` incluye el diseño compartido, la organización de componentes y el prototipo. También se puede abrir en línea: https://www.figma.com/design/0DCn9d2JJFMS2nLgepZWt8/LIQUIDA-Analytics-%E2%80%94-Mockups-de-Dashboard

Los mockups son referencias visuales de las tres páginas implementadas en Power BI; no son capturas tomadas de Power BI Desktop. Los valores son sintéticos y deben contrastarse con los CSV/modelo antes de interpretarlos.

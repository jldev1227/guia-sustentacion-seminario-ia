$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataPath = (Join-Path $projectRoot '00_DATOS\limpio').TrimEnd('\') + '\'
$expressionFile = Join-Path $projectRoot '06_DASHBOARD.SemanticModel\definition\expressions.tmdl'

if (-not (Test-Path -LiteralPath $expressionFile)) {
    throw "No se encontró la definición del modelo: $expressionFile"
}

$content = [System.IO.File]::ReadAllText($expressionFile, [System.Text.Encoding]::UTF8)
$pattern = '(?m)^expression RutaDatos = ".*?" meta \[IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true\]\r?$'
$matches = [regex]::Matches($content, $pattern)
if ($matches.Count -ne 1) {
    throw "Se esperaba una definición RutaDatos y se encontraron $($matches.Count). No se modificó el archivo."
}

$escapedPath = $dataPath.Replace('"', '""')
$replacement = 'expression RutaDatos = "' + $escapedPath + '" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
$updated = [regex]::Replace($content, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $replacement })
[System.IO.File]::WriteAllText($expressionFile, $updated, [System.Text.UTF8Encoding]::new($false))

Write-Host "Parámetro RutaDatos configurado en: $dataPath"
Write-Host 'Ahora abra 06_DASHBOARD.pbip con Power BI Desktop y actualice el modelo.'

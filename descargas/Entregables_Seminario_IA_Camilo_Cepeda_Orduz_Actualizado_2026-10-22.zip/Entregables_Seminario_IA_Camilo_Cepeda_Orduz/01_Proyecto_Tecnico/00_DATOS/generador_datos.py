"""
GENERADOR DE DATOS SINTÉTICOS DE PRÁCTICA
Proyecto: Dashboard de Liquidacion y Facturacion de Servicios de Transporte Especial

QUE HACE
    Produce los archivos crudos que alimentan el proyecto, replicando la estructura,
    las reglas de cálculo definidas para este ejercicio de liquidación de
    servicios de transporte especial de personal.

IMPORTANTE
    Este script NO es el pipeline ETL. Genera datos DELIBERADAMENTE SUCIOS, tal como
    llegarian de un export manual del sistema. Limpiarlos es trabajo del archivo
    04_PIPELINE.py, que es el entregable evaluado.

CONFIDENCIALIDAD
    Ningun registro proviene de una base de datos real. Los valores monetarios estan
    transformados por un factor de escala. Se conservan distribuciones, estacionalidad
    y relaciones entre variables; no se conserva ningun dato identificable.

USO
    python generador_datos.py
"""

import json
import random
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
RAW = BASE / "raw"


# ──────────────────────────────────────────────────────────────────────
# 1. CARGA DE PARAMETROS
# ──────────────────────────────────────────────────────────────────────

def cargar_calibracion():
    """Lee los parámetros didácticos del conjunto sintético."""
    with open(BASE / "calibracion.json", encoding="utf-8") as f:
        return json.load(f)


CAL = cargar_calibracion()
random.seed(CAL["semilla"])
rng = np.random.default_rng(CAL["semilla"])


# ──────────────────────────────────────────────────────────────────────
# 2. CATALOGOS
# ──────────────────────────────────────────────────────────────────────

OPERADORAS = CAL["catalogos"]["operadoras"]
CLIENTES = CAL["catalogos"]["clientes"]
VEHICULOS = [f"VEH-{i:03d}" for i in range(1, CAL["catalogos"]["vehiculos"] + 1)]
TERCEROS = [f"TER-{i:03d}" for i in range(1, CAL["catalogos"]["terceros"] + 1)]
RECORRIDOS = [f"RUT-{i:02d}" for i in range(1, CAL["catalogos"]["recorridos"] + 1)]
TIPOS = list(CAL["tarifas"].keys())
PESOS_TIPO = [CAL["tarifas"][t]["peso"] for t in TIPOS]

# Cada cliente pertenece a una operadora fija
CLIENTE_OPERADORA = {c: OPERADORAS[i % len(OPERADORAS)] for i, c in enumerate(CLIENTES)}

# Rutas largas: son las que generan pernoctes
RECORRIDOS_LARGOS = set(RECORRIDOS[:5])


# ──────────────────────────────────────────────────────────────────────
# 3. HELPERS DE NEGOCIO
# ──────────────────────────────────────────────────────────────────────

def periodos():
    """Lista de (anio, mes) de la ventana configurada."""
    anio, mes = map(int, CAL["ventana"]["anio_mes_inicio"].split("-"))
    salida = []
    for _ in range(CAL["ventana"]["meses"]):
        salida.append((anio, mes))
        mes += 1
        if mes > 12:
            mes, anio = 1, anio + 1
    return salida


def factor_tarifa(anio, mes, operadora, anio_base):
    """Ajuste anual por inflacion, estacionalidad del mes y diferencial de operadora."""
    inflacion = (1 + CAL["ajuste_tarifa_anual"]) ** (anio - anio_base)
    estacional = CAL["estacionalidad_mensual"][str(mes)]
    diferencial = CAL["diferencial_operadora"][operadora]
    return inflacion * estacional * diferencial


def valor_unitario(tipo, factor):
    """Tarifa del tipo de servicio, con dispersion y ajuste aplicado."""
    t = CAL["tarifas"][tipo]
    base = rng.normal(t["valor"], t["desv"])
    return max(1000, round(base * factor))


def cantidad(tipo):
    """Cantidad facturada segun el tipo de tarifa."""
    t = CAL["tarifas"][tipo]
    if t["cantidad_desv"] == 0:
        return round(t["cantidad_media"], 2)
    return round(max(0.5, rng.normal(t["cantidad_media"], t["cantidad_desv"])), 2)


def estado_liquidacion(indice_mes, total_meses):
    """
    Los periodos recientes tienden a estar en estados tempranos del flujo:
    lo que se liquido hace un anio ya esta facturado.
    """
    d = dict(CAL["distribucion_estados"])
    antiguedad = indice_mes / max(1, total_meses - 1)
    if antiguedad > 0.88:                       # ultimos ~3 meses
        d = {"FACTURADA": 0.18, "APROBADA": 0.30, "LIQUIDADA": 0.28,
             "BORRADOR": 0.20, "ANULADA": 0.04}
    elif antiguedad > 0.75:
        d = {"FACTURADA": 0.52, "APROBADA": 0.22, "LIQUIDADA": 0.12,
             "BORRADOR": 0.10, "ANULADA": 0.04}
    return random.choices(list(d.keys()), weights=list(d.values()))[0]


def dias(clave):
    """Dias que tarda una transicion de estado. Cola larga en el cuello de botella."""
    p = CAL["dias_entre_estados"][clave]
    return max(1, int(round(rng.normal(p["media"], p["desv"]))))


# ──────────────────────────────────────────────────────────────────────
# 4. GENERACION DEL DETALLE (ITEMS)
# ──────────────────────────────────────────────────────────────────────

def generar_items(consecutivo, anio, mes, operadora, anio_base):
    """Genera las lineas de servicio de una liquidacion."""
    cfg = CAL["items_por_liquidacion"]
    n = int(np.clip(rng.normal(cfg["media"], cfg["desv"]), cfg["minimo"], cfg["maximo"]))
    factor = factor_tarifa(anio, mes, operadora, anio_base)
    dias_mes = (date(anio + (mes == 12), mes % 12 + 1, 1) - timedelta(days=1)).day

    items = []
    for _ in range(n):
        tipo = random.choices(TIPOS, weights=PESOS_TIPO)[0]
        recorrido = random.choice(RECORRIDOS)
        dia_ini = random.randint(1, dias_mes)
        duracion = random.randint(0, 3) if tipo in ("HORA_24", "HORA_12") else 0
        f_ini = date(anio, mes, dia_ini)
        f_fin = min(f_ini + timedelta(days=duracion), date(anio, mes, dias_mes))

        cant = cantidad(tipo)
        vu = valor_unitario(tipo, factor)

        # Descuento comercial ocasional
        if random.random() < CAL["descuentos"]["proporcion_items_con_descuento"]:
            d = CAL["descuentos"]
            pct = round(max(0.5, rng.normal(d["porcentaje_medio"], d["porcentaje_desv"])), 2)
        else:
            pct = 0.0

        # Los pernoctes se concentran en las rutas largas
        prob_pernocte = 0.55 if recorrido in RECORRIDOS_LARGOS else 0.06
        if random.random() < prob_pernocte:
            n_pernoctes = random.randint(1, 3)
            v_pernocte = round(CAL["composicion_ingreso"]["valor_pernocte"] * factor)
        else:
            n_pernoctes, v_pernocte = 0, 0

        subtotal = round(cant * vu, 2)
        items.append({
            "consecutivo": consecutivo,
            "placa": random.choice(VEHICULOS),
            "fecha_inicial": f_ini,
            "fecha_final": f_fin,
            "recorrido": recorrido,
            "tipo_servicio": tipo,
            "cantidad": cant,
            "valor_unitario": vu,
            "subtotal": subtotal,
            "porcentaje_descuento": pct,
            "valor_final": round(subtotal * (1 - pct / 100), 2),
            "numero_planilla": f"PL-{random.randint(100000, 999999)}",
            "cantidad_pernoctes": n_pernoctes,
            "valor_pernocte_unitario": v_pernocte,
            "tercero": (random.choice(TERCEROS)
                        if random.random() < CAL["proporcion_items_tercero"] else ""),
        })
    return items


# ──────────────────────────────────────────────────────────────────────
# 5. GENERACION DE CABECERAS E HISTORIAL
# ──────────────────────────────────────────────────────────────────────

def generar_dataset():
    lista_periodos = periodos()
    anio_base = lista_periodos[0][0]
    cab, det, hist = [], [], []
    consecutivo_n = 1

    for i, (anio, mes) in enumerate(lista_periodos):
        for cliente in CLIENTES:
            if random.random() < CAL["meses_sin_liquidacion"]:
                continue

            operadora = CLIENTE_OPERADORA[cliente]
            consecutivo = f"LQ-{anio}{mes:02d}-{consecutivo_n:04d}"
            consecutivo_n += 1

            items = generar_items(consecutivo, anio, mes, operadora, anio_base)
            det.extend(items)

            # Totales derivados del detalle (regla de negocio real)
            comp = CAL["composicion_ingreso"]
            valor_servicios = round(sum(it["valor_final"] for it in items), 2)
            valor_pernoctes = round(sum(it["cantidad_pernoctes"] * it["valor_pernocte_unitario"]
                                        for it in items), 2)
            valor_recargos = round(valor_servicios * comp["proporcion_recargos"]
                                   * rng.uniform(0.75, 1.25), 2)
            valor_ta = round(valor_servicios * comp["proporcion_transporte_adicional"]
                             * rng.uniform(0.6, 1.4), 2)
            valor_admin = round(valor_ta * comp["tasa_administracion_ta"], 2)

            subtotal = round(valor_servicios + valor_recargos + valor_ta
                             + valor_admin + valor_pernoctes, 2)
            iva_pct = CAL["porcentaje_iva"]
            valor_iva = round(subtotal * iva_pct / 100, 2)

            estado = estado_liquidacion(i, len(lista_periodos))
            ultimo_dia = (date(anio + (mes == 12), mes % 12 + 1, 1) - timedelta(days=1))
            f_liq = ultimo_dia + timedelta(days=random.randint(1, 6))

            # Recorrido del flujo de estados
            f_aprob = f_fact = None
            secuencia = ["BORRADOR", "LIQUIDADA", "APROBADA", "FACTURADA"]
            fecha_cursor = f_liq
            if estado != "BORRADOR":
                hist.append({"consecutivo": consecutivo, "estado_anterior": "",
                             "estado_nuevo": "BORRADOR", "fecha": f_liq,
                             "usuario": f"USR-{random.randint(1, 6):02d}"})
                alcance = (secuencia.index(estado) if estado in secuencia
                           else random.randint(1, 3))
                for paso in range(alcance):
                    origen, destino = secuencia[paso], secuencia[paso + 1]
                    fecha_cursor = fecha_cursor + timedelta(days=dias(f"{origen}_{destino}"))
                    hist.append({"consecutivo": consecutivo, "estado_anterior": origen,
                                 "estado_nuevo": destino, "fecha": fecha_cursor,
                                 "usuario": f"USR-{random.randint(1, 6):02d}"})
                    if destino == "APROBADA":
                        f_aprob = fecha_cursor
                    if destino == "FACTURADA":
                        f_fact = fecha_cursor
                if estado == "ANULADA":
                    fecha_cursor = fecha_cursor + timedelta(days=random.randint(1, 10))
                    hist.append({"consecutivo": consecutivo,
                                 "estado_anterior": secuencia[alcance],
                                 "estado_nuevo": "ANULADA", "fecha": fecha_cursor,
                                 "usuario": f"USR-{random.randint(1, 6):02d}"})

            cab.append({
                "consecutivo": consecutivo,
                "cliente": cliente,
                "operadora": operadora,
                "mes": mes,
                "anio": anio,
                "fecha_liquidacion": f_liq,
                "valor_servicios": valor_servicios,
                "valor_recargos": valor_recargos,
                "valor_transporte_adicional": valor_ta,
                "valor_administracion_ta": valor_admin,
                "valor_pernoctes": valor_pernoctes,
                "subtotal": subtotal,
                "porcentaje_iva": iva_pct,
                "valor_iva": valor_iva,
                "total": round(subtotal + valor_iva, 2),
                "estado": estado,
                "fecha_aprobacion": f_aprob,
                "fecha_facturacion": f_fact,
                "motivo_anulacion": (random.choice(CAL["motivos_anulacion"])
                                     if estado == "ANULADA" else ""),
                "observaciones": "",
            })

    return pd.DataFrame(cab), pd.DataFrame(det), pd.DataFrame(hist)


# ──────────────────────────────────────────────────────────────────────
# 6. INYECCION DE SUCIEDAD
#    Reproduce los defectos tipicos de un export manual. Es la materia
#    prima del analisis exploratorio y del pipeline de limpieza.
# ──────────────────────────────────────────────────────────────────────

def ensuciar(cab, det):
    """
    El orden de los pasos importa. Primero se alteran los VALORES del detalle,
    despues se recalculan los totales de la cabecera sobre esos valores ya
    alterados, y solo al final se inyecta el descuadre deliberado. Asi el unico
    descuadre que encuentra el pipeline es el que se quiso poner, y no un efecto
    secundario de los valores atipicos.
    """
    s = CAL["suciedad"]

    # ── PASO 1. Alteracion de valores en el detalle ──────────────────
    # Valores atipicos: errores de digitacion en cantidad o tarifa
    idx = det.sample(frac=s["outliers_items"], random_state=CAL["semilla"] + 4).index
    for i in idx:
        if random.random() < 0.5:
            det.at[i, "cantidad"] = round(float(det.at[i, "cantidad"]) * random.uniform(8, 22), 2)
        else:
            det.at[i, "valor_unitario"] = round(float(det.at[i, "valor_unitario"])
                                                * random.uniform(9, 18))

    det["subtotal"] = (det["cantidad"] * det["valor_unitario"]).round(2)
    det["valor_final"] = (det["subtotal"] * (1 - det["porcentaje_descuento"] / 100)).round(2)

    # ── PASO 2. Los totales de cabecera se derivan del detalle sintético ──
    comp = CAL["composicion_ingreso"]
    suma = det.groupby("consecutivo")["valor_final"].sum()
    cab["valor_servicios"] = cab["consecutivo"].map(suma).fillna(0).round(2)
    cab["subtotal"] = (cab["valor_servicios"] + cab["valor_recargos"]
                       + cab["valor_transporte_adicional"] + cab["valor_administracion_ta"]
                       + cab["valor_pernoctes"]).round(2)
    cab["valor_iva"] = (cab["subtotal"] * cab["porcentaje_iva"] / 100).round(2)
    cab["total"] = (cab["subtotal"] + cab["valor_iva"]).round(2)

    # ── PASO 3. Suciedad de la cabecera ──────────────────────────────
    # Operadora escrita de cuatro formas distintas (campo de texto libre)
    variantes = [lambda x: x, lambda x: x.lower(),
                 lambda x: x.replace("-", " "), lambda x: f"  {x} "]
    cab["operadora"] = [random.choice(variantes)(v) for v in cab["operadora"]]

    # Observaciones en blanco la mayor parte del tiempo
    notas = ["Revisado por coordinacion", "Pendiente soporte de planillas",
             "Incluye servicios del periodo anterior", "Ajuste acordado con la operadora"]
    cab["observaciones"] = [
        "" if random.random() < s["nulos_observaciones"] else random.choice(notas)
        for _ in range(len(cab))
    ]

    # Descuadre deliberado: el valor declarado no coincide con el detalle
    idx = cab.sample(frac=s["descuadre_cabecera"], random_state=CAL["semilla"]).index
    factor = rng.uniform(0.90, 1.10, len(idx))
    cab.loc[idx, "valor_servicios"] = (cab.loc[idx, "valor_servicios"] * factor).round(2)

    # ── PASO 4. Suciedad de formato en el detalle (no cambia valores) ─
    idx = det.sample(frac=s["nulos_numero_planilla"], random_state=CAL["semilla"]).index
    det.loc[idx, "numero_planilla"] = ""

    idx = det.sample(frac=s["formato_placa"], random_state=CAL["semilla"] + 1).index
    det.loc[idx, "placa"] = [
        random.choice([p.replace("-", ""), p.replace("-", " "), p.lower()])
        for p in det.loc[idx, "placa"]
    ]

    # Valor unitario exportado como texto con formato de moneda ("$452.000")
    idx = det.sample(frac=s["valor_unitario_texto"], random_state=CAL["semilla"] + 2).index
    det["valor_unitario"] = det["valor_unitario"].astype(object)
    det.loc[idx, "valor_unitario"] = [f"${int(v):,}".replace(",", ".")
                                      for v in det.loc[idx, "valor_unitario"]]

    # Fechas en formato dd/mm/aaaa
    idx = det.sample(frac=s["fecha_formato_alterno"], random_state=CAL["semilla"] + 3).index
    det["fecha_inicial"] = det["fecha_inicial"].astype(object)
    det.loc[idx, "fecha_inicial"] = [d.strftime("%d/%m/%Y") for d in det.loc[idx, "fecha_inicial"]]

    # ── PASO 5. Filas sobrantes por errores de carga ─────────────────
    n_dup = int(len(det) * s["duplicados_items"])
    duplicados = det.sample(n=n_dup, random_state=CAL["semilla"] + 5)
    det = pd.concat([det, duplicados], ignore_index=True)

    n_huerf = int(len(det) * s["items_huerfanos"])
    huerfanos = det.sample(n=n_huerf, random_state=CAL["semilla"] + 6).copy()
    huerfanos["consecutivo"] = [f"LQ-XXXX-{random.randint(9000, 9999)}" for _ in range(n_huerf)]
    det = pd.concat([det, huerfanos], ignore_index=True)

    # Se mezcla el orden para incluir variación de secuencia de entrada
    det = det.sample(frac=1, random_state=CAL["semilla"]).reset_index(drop=True)
    return cab, det


# ──────────────────────────────────────────────────────────────────────
# 7. SALIDA
# ──────────────────────────────────────────────────────────────────────

def main():
    RAW.mkdir(parents=True, exist_ok=True)
    print("Generando conjunto sintético de práctica...")

    cab, det, hist = generar_dataset()
    cab, det = ensuciar(cab, det)

    # Tres formatos distintos, como llegarian de tres fuentes distintas
    cab.to_excel(RAW / "liquidaciones_cabecera.xlsx", index=False)
    det.to_csv(RAW / "liquidaciones_items.csv", index=False, encoding="utf-8-sig")
    hist.to_csv(RAW / "historial_estados.csv", index=False, encoding="utf-8-sig")

    print(f"  liquidaciones_cabecera.xlsx   {len(cab):>6,} filas")
    print(f"  liquidaciones_items.csv       {len(det):>6,} filas")
    print(f"  historial_estados.csv         {len(hist):>6,} filas")
    print(f"\nPeriodo: {cab['anio'].min()} a {cab['anio'].max()}")
    print(f"Archivos en: {RAW}")


if __name__ == "__main__":
    main()

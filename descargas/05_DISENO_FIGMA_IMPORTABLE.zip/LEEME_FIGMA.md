# Entregable 05 · Diseño de visualizaciones

Este entregable documenta las **tres vistas del tablero de Power BI implementado** y el sistema visual que las organiza.

## Archivo Figma

[Abrir LIQUIDA Analítica · Maquetas del tablero](https://www.figma.com/design/0DCn9d2JJFMS2nLgepZWt8/LIQUIDA-Analytics-%E2%80%94-Mockups-de-Dashboard)

El archivo tiene tres páginas, con el nombre de las pestañas del reporte:

1. **01 · Visión ejecutiva** — cinco tarjetas KPI, evolución mensual, valor por operadora, composición del ingreso y liquidaciones por estado.
2. **02 · Detalle operacional** — ingresos por vehículo, recorrido y tipo de tarifa; comparación de flota propia/terceros; tabla de 122 servicios atípicos.
3. **03 · Tiempos y comparativos** — tiempos por etapa, ciclo completo con referencia de 15 días, motivos de anulación y comparativo interanual.

Cada lienzo mide **1280 × 720 px (16:9)** y conserva los filtros sincronizados de período y operadora. La vista ejecutiva está construida con capas nativas de Figma. Las vistas operacional y de tiempos se importaron como SVG vectoriales: sus textos y formas son capas editables, no una captura plana ni un prototipo de aplicación web.

## Paquete local

- `01_vision_ejecutiva.svg`, `02_detalle_operacional.svg` y `03_tiempos_comparativos.svg`: fuentes vectoriales de las vistas para volver a importar o editar.
- `05_DISENO_VISUALIZACIONES.pdf`: documento de ocho páginas. Incluye sistema visual, indicadores, interacción y las tres vistas del reporte.
- `design-tokens.json`: proporción, paleta y mapa de visualizaciones para los 12 indicadores definidos en el proyecto.

## Fuente y alcance

El diseño se contrastó con las vistas implementadas del tablero, sus filtros, el tema visual y los datos depurados del proyecto. Las cifras proceden de un conjunto de datos sintético con fines académicos.

Para volver a importar una vista, arrastra su SVG a una página de Figma o usa **Archivo → Colocar imagen**. Figma conserva los textos y vectores como objetos editables. El archivo enlazado ya contiene las tres páginas.

Se conservan sin traducir los nombres oficiales del software, las siglas y las rutas exactas de los archivos. El enlace abre el archivo compartido de Figma, cuyo identificador y dirección no se modifican.

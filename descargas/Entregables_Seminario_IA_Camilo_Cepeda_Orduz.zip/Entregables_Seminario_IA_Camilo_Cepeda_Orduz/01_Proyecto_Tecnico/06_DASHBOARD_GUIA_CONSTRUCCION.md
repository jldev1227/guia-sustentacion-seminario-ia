# Entregable 6 · Guía de construcción del tablero

Instrucciones paso a paso para armar `06_DASHBOARD.pbix` en **Power BI Desktop (Windows)**.
Todo lo demás del proyecto ya está hecho; esto es lo único que requiere Windows.

**Tiempo estimado: 2 a 3 horas.**

---

## Antes de empezar

1. Clonar o descargar el repositorio en la máquina Windows.
2. Verificar que existe la carpeta `00_DATOS/limpio/` con cinco archivos CSV.
   Si no está, ejecutar el pipeline primero:
   ```
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python 04_PIPELINE.py
   ```
3. Instalar **Power BI Desktop** desde la Microsoft Store (gratis).

---

## Paso 1 · Cargar los datos

`Inicio → Obtener datos → Texto/CSV`. Cargar los cuatro archivos:

| Archivo | Tabla | Rol |
|---------|-------|-----|
| `liquidaciones.csv` | `Liquidaciones` | Hechos — cabecera |
| `items.csv` | `Items` | Hechos — detalle |
| `tiempos_proceso.csv` | `Tiempos` | Hechos — transiciones de estado |
| `kpis_mensuales.csv` | `KPIs` | Agregado precalculado |

> **Importante:** en el diálogo de importación, poner **Origen de archivo: UTF-8** para que las
> tildes se lean bien. El pipeline escribe con BOM, así que Power BI suele detectarlo solo.

En el editor de Power Query, verificar los tipos:
- `periodo`, `fecha_liquidacion`, `fecha_aprobacion`, `fecha_facturacion`, `fecha_inicial`, `fecha_final` → **Fecha**
- Todas las columnas de valor → **Número decimal**
- `es_anulada`, `es_facturada`, `es_tercero`, `es_anomalia`, `tiene_planilla` → **Verdadero/Falso**

`Cerrar y aplicar`.

---

## Paso 2 · Crear la tabla de calendario

Sin una tabla de fechas propia, los filtros temporales no funcionan bien.
`Modelado → Nueva tabla`:

```dax
Calendario =
ADDCOLUMNS(
    CALENDAR(DATE(2024,9,1), DATE(2026,8,31)),
    "Año", YEAR([Date]),
    "Mes", MONTH([Date]),
    "NombreMes", FORMAT([Date], "MMM"),
    "AñoMes", FORMAT([Date], "yyyy-MM"),
    "Trimestre", "T" & QUARTER([Date])
)
```

Luego `Modelado → Marcar como tabla de fechas` y elegir la columna `Date`.

---

## Paso 3 · Relaciones del modelo

`Modelado → Administrar relaciones`. Crear cuatro:

| Desde | Hacia | Cardinalidad |
|-------|-------|--------------|
| `Liquidaciones[consecutivo]` | `Items[consecutivo]` | 1 a varios |
| `Liquidaciones[consecutivo]` | `Tiempos[consecutivo]` | 1 a varios |
| `Calendario[Date]` | `Liquidaciones[periodo]` | 1 a varios |
| `Calendario[Date]` | `KPIs[periodo]` | 1 a varios |

Todas con dirección de filtro **simple** (desde la tabla del lado «1»).

---

## Paso 4 · Medidas DAX

`Modelado → Nueva medida`. Una por una. Los nombres coinciden con los códigos del entregable 3.

```dax
-- K01
Valor liquidado =
CALCULATE(SUM(Liquidaciones[total]), Liquidaciones[es_anulada] = FALSE)

-- K02
Valor facturado =
CALCULATE(SUM(Liquidaciones[total]), Liquidaciones[es_facturada] = TRUE)

-- K03
Ticket promedio =
CALCULATE(AVERAGE(Liquidaciones[total]), Liquidaciones[es_anulada] = FALSE)

-- K04
Dias a facturacion =
CALCULATE(AVERAGE(Liquidaciones[dias_a_facturacion]), Liquidaciones[es_anulada] = FALSE)

-- K05
Dias en aprobacion =
CALCULATE(
    AVERAGE(Tiempos[dias_en_etapa]),
    Tiempos[transicion] = "LIQUIDADA -> APROBADA"
)

-- K06
Pct recargos =
DIVIDE(
    CALCULATE(SUM(Liquidaciones[valor_recargos]), Liquidaciones[es_anulada] = FALSE),
    CALCULATE(SUM(Liquidaciones[valor_servicios]), Liquidaciones[es_anulada] = FALSE)
) * 100

-- K07
Pct transporte adicional =
DIVIDE(
    CALCULATE(SUM(Liquidaciones[valor_transporte_adicional]), Liquidaciones[es_anulada] = FALSE),
    CALCULATE(SUM(Liquidaciones[valor_servicios]), Liquidaciones[es_anulada] = FALSE)
) * 100

-- K08 / K09 · se usan directamente en los visuales agrupando por placa o recorrido
Valor items = SUM(Items[valor_final])

-- K10
Tasa de anulacion =
DIVIDE(
    CALCULATE(COUNTROWS(Liquidaciones), Liquidaciones[es_anulada] = TRUE),
    COUNTROWS(Liquidaciones)
) * 100

-- K11
Descuento promedio = AVERAGE(Items[porcentaje_descuento])

-- K12
Pct terceros =
DIVIDE(
    CALCULATE(SUM(Items[valor_final]), Items[es_tercero] = TRUE),
    SUM(Items[valor_final])
) * 100

-- Auxiliares
Num liquidaciones = COUNTROWS(Liquidaciones)
Num items atipicos = CALCULATE(COUNTROWS(Items), Items[es_anomalia] = TRUE)
Brecha liquidado facturado = [Valor liquidado] - [Valor facturado]
```

**Formato de cada medida** (pestaña `Herramientas de medidas`):
- Valores en pesos → Moneda, 0 decimales, separador de miles
- Porcentajes y días → Número decimal, 1 decimal

---

## Paso 5 · Tema visual

`Ver → Temas → Personalizar tema actual`. Colores en este orden exacto:

| Posición | Hex | Uso |
|----------|-----|-----|
| 1 | `#2C6A4F` | Serie principal · Operadora A |
| 2 | `#A85F22` | Serie secundaria · Operadora B · énfasis |
| 3 | `#8FB5A6` | Series de apoyo |
| 4 | `#13302D` | Texto y ejes |
| 5 | `#A3382E` | Alerta y anulaciones |
| 6 | `#B8860B` | Atención |

Tipografía: **Segoe UI**. Fondo de página `#FFFFFF`, fondo de tarjeta `#F1F5F3`.

Las especificaciones completas están en `05_DISENO.pdf`, sección 7.

---

## Paso 6 · Página 1 · Visión ejecutiva

Renombrar la pestaña a **Visión ejecutiva**.

**Filtros (segmentaciones) en la parte superior**, sincronizados a las tres páginas
(`Ver → Sincronizar segmentaciones`):
- `Calendario[Date]` → estilo «Entre»
- `Liquidaciones[operadora]` → lista desplegable, selección múltiple

**Fila de tarjetas** (visual *Tarjeta*), cinco en línea:

| Tarjeta | Medida |
|---------|--------|
| Valor liquidado | `[Valor liquidado]` |
| Valor facturado | `[Valor facturado]` |
| Ticket promedio | `[Ticket promedio]` |
| Días a factura | `[Dias a facturacion]` |
| Tasa de anulación | `[Tasa de anulacion]` |

**Gráfico de líneas** — Evolución mensual
Eje X: `Calendario[AñoMes]` · Valores: `[Valor liquidado]` y `[Valor facturado]` · Leyenda arriba.

**Gráfico de columnas apiladas 100%** — Composición del ingreso
Eje X: `Calendario[AñoMes]` · Valores: `valor_servicios`, `valor_recargos`,
`valor_transporte_adicional`, `valor_pernoctes` (suma de cada uno).

**Gráfico de columnas** — Valor por operadora
Eje X: `Liquidaciones[operadora]` · Valor: `[Valor liquidado]`.

**Gráfico de columnas** — Liquidaciones por estado
Eje X: `Liquidaciones[estado]` · Valor: `[Num liquidaciones]`.

---

## Paso 7 · Página 2 · Detalle operacional

**Gráfico de barras horizontales** — Ingreso por vehículo
Eje Y: `Items[placa]` · Valor: `[Valor items]` · Filtro: N superior = 15 · Orden descendente.

**Gráfico de barras horizontales** — Ingreso por recorrido
Eje Y: `Items[recorrido]` · Valor: `[Valor items]` · Orden descendente.

**Gráfico de columnas** — Valor por tipo de tarifa
Eje X: `Items[tipo_servicio]` · Valor: `[Valor items]`.

**Gráfico de columnas apiladas** — Flota propia frente a terceros
Eje X: `Calendario[AñoMes]` · Leyenda: `Items[es_tercero]` · Valor: `[Valor items]`.

**Tabla** — Items marcados como atípicos
Columnas: `consecutivo`, `placa`, `recorrido`, `tipo_servicio`, `cantidad`, `valor_unitario`,
`motivo_anomalia`. Filtro de nivel de visual: `es_anomalia` = `True`.
Orden: `valor_unitario` descendente.

**Segmentación adicional**: `Items[es_anomalia]` como interruptor, solo en esta página.

---

## Paso 8 · Página 3 · Tiempos y comparativos

**Cuatro tarjetas** en la parte superior:
- Borrador → Liquidada, Liquidada → Aprobada, Aprobada → Facturada: usar el visual *Gráfico de
  barras* con `Tiempos[transicion]` en el eje y `AVERAGE(Tiempos[dias_en_etapa])` como valor, o
  crear tres medidas con `CALCULATE` filtrando cada transición.
- Ciclo completo: `[Dias a facturacion]`.

**Gráfico de barras horizontales** — Días por etapa del flujo
Eje Y: `Tiempos[transicion]` · Valor: promedio de `dias_en_etapa`
Filtro: excluir transiciones hacia `ANULADA` y la fila `INICIO -> BORRADOR`.
**Resaltar la barra `LIQUIDADA -> APROBADA` en ocre** (`#A85F22`) con reglas de color condicional.

**Gráfico de líneas** — Evolución del ciclo completo
Eje X: `Calendario[AñoMes]` · Valor: `[Dias a facturacion]`
Añadir línea constante en **15** (`Analítica → Línea constante`), etiquetada «Referencia K04».

**Gráfico de barras horizontales** — Anulaciones por motivo
Eje Y: `Liquidaciones[motivo_anulacion]` · Valor: `[Num liquidaciones]`
Filtro: `es_anulada` = `True` · Color: `#A3382E`.

**Gráfico de columnas agrupadas** — Comparativo año contra año
Eje X: `Calendario[NombreMes]` · Leyenda: `Calendario[Año]` · Valor: `[Valor liquidado]`.

---

## Paso 9 · Interactividad

1. **Sincronizar segmentaciones** de período y operadora en las tres páginas.
2. **Profundizar de página 1 a página 2**: clic derecho sobre el gráfico de evolución →
   `Obtener detalles` → `Detalle operacional`. Activar `Mantener todos los filtros`.
3. **Información sobre herramientas**: activar en los gráficos de barras para que al pasar el cursor
   se vea el valor exacto.
4. **Interacciones entre visuales**: `Formato → Editar interacciones`. Desactivar el filtrado cruzado
   desde la tabla de atípicos hacia el resto de la página 2 (si no, seleccionar una fila vacía el resto).

---

## Paso 10 · Revisión antes de guardar

- [ ] Las tres páginas cargan sin errores de relación
- [ ] Los filtros de período y operadora afectan las tres páginas
- [ ] Ningún visual muestra «(En blanco)» donde debería haber datos
- [ ] Las cifras de las tarjetas coinciden con `00_DATOS/limpio/kpis_mensuales.csv`
- [ ] Los colores siguen el tema de `05_DISENO.pdf`
- [ ] Cada visual tiene título descriptivo con el código del indicador entre paréntesis
- [ ] Los nombres de las páginas son los tres definidos, no «Página 1»
- [ ] El archivo se guarda como `06_DASHBOARD.pbix` en la raíz del proyecto

### Verificación cruzada de cifras

Comparar contra los valores que produjo el pipeline:

| Indicador | Valor esperado (24 meses) |
|-----------|---------------------------|
| Valor liquidado total | ≈ $3.604 millones |
| Ticket promedio | ≈ $27,8 millones |
| Días a facturación | ≈ 18,0 |
| Días en aprobación | ≈ 10,8 |
| Participación de recargos | ≈ 10,1% |
| Participación de terceros | ≈ 29,7% |
| Items atípicos | 122 |

Si alguna cifra no coincide, casi siempre es por el filtro de anuladas o por una relación mal
orientada en el modelo.

---

## Si Power BI Desktop no está disponible

El marco del proyecto acepta `.pbix` **«o equivalente»**. Alternativas:

| Herramienta | Salida | Notas |
|-------------|--------|-------|
| **Looker Studio** | Enlace + PDF | Gratuito, web, funciona en cualquier sistema. Cargar los CSV a Google Sheets y conectar desde ahí |
| **Tableau Public** | `.twbx` | Gratuito, hay versión para macOS. Los libros quedan públicos |

En cualquiera de los dos casos, la estructura de tres páginas, los indicadores y el tema visual se
mantienen igual. **Confirmar con el docente antes de optar por un formato distinto a `.pbix`.**

# Guion de apoyo para el video de sustentación

**Duración objetivo:** 5 minutos · **Autor:** Camilo Cepeda Orduz  
**Importante:** este archivo es un guion para grabar; no es una grabación de video.

## 0:00–0:30 · Presentación

Buenos días. Soy Camilo Cepeda Orduz y presento el proyecto “De liquidaciones a decisiones visibles”, realizado para la Opción de grado del Seminario de Inteligencia Artificial 2026-2. El trabajo estudia, con fines académicos, cómo preparar y visualizar información de un proceso de liquidación de servicios de transporte especial.

## 0:30–1:05 · Pregunta y alcance

El proyecto se organiza alrededor de preguntas concretas: cuánto se liquida y factura, cuánto tarda cada etapa, cómo se compone el valor y dónde aparecen registros que requieren revisión. El alcance incluye siete piezas: requisitos, análisis exploratorio, indicadores, ETL, diseño visual, tablero y documentación.

## 1:05–1:45 · Datos y límites

Los registros del proyecto son sintéticos. No proceden de una operación real y sus cantidades no estiman el comportamiento de una empresa. Se utilizan para mostrar el método de trabajo y hacer reproducibles los cálculos. El conjunto contiene registros de cabecera, detalle e historial de estados; el pipeline documenta las transformaciones y validaciones aplicadas.

## 1:45–2:35 · Exploración y preparación

La exploración identifica tipos, faltantes, duplicados, relaciones y valores inusuales. En el conjunto de práctica se detectaron duplicados exactos, referencias sin cabecera y líneas sin número de planilla. El ETL aplica reglas separadas para validar unicidad, integridad, completitud y consistencia. Una alerta no demuestra por sí misma que exista un error comercial; los casos que pueden afectar una liquidación necesitan revisión humana.

## 2:35–3:35 · Indicadores y tablero

El catálogo documenta doce indicadores y sus fórmulas. El proyecto Power BI se divide en tres páginas: visión ejecutiva, detalle operacional y tiempos comparativos. Las visualizaciones permiten segmentar el conjunto por periodo y categoría. El tablero se entrega en formato PBIP; para abrirlo, ejecutar primero el script de configuración local y después actualizar los datos en Power BI Desktop.

## 3:35–4:20 · Resultado analítico

El análisis usa el rango intercuartílico para señalar valores alejados de la distribución de su grupo. Se trata de un mecanismo explicable para priorizar revisión, no de una clasificación de fraude. Las métricas de tiempos describen únicamente el conjunto generado. Para aplicar los mismos controles a una empresa se requerirían datos autorizados, reglas validadas con sus responsables y una evaluación distinta.

## 4:20–5:00 · Cierre

La conclusión principal es que la calidad de los datos condiciona la confianza que puede depositarse en los indicadores y en cualquier modelo posterior. Antes de seleccionar una técnica de inteligencia artificial conviene documentar la procedencia, medir las dimensiones relevantes y asignar responsable a las validaciones. El paquete incluye los documentos, notebooks, pipeline, catálogo, diseño, proyecto Power BI y presentación. Gracias.

## Preparación de la grabación

1. Abrir las diapositivas y el tablero en Power BI Desktop.
2. Grabar pantalla y voz con una herramienta de captura disponible en el equipo.
3. Mantener el archivo dentro de los cinco minutos indicados en la guía.
4. Revisar que el audio sea claro y que el video muestre el tablero y la presentación.
5. Guardar la grabación final en MP4 y añadirla al paquete antes de la entrega académica.

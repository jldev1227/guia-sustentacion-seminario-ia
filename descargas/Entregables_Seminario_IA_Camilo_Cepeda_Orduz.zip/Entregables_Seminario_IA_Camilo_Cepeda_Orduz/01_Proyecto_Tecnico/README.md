# Dashboard de Liquidación y Facturación de Servicios de Transporte Especial

**Opción de grado · Seminario de Inteligencia Artificial 2026-2**  
Camilo Cepeda Orduz · Entregable técnico

Proyecto académico de inteligencia de negocios sobre la liquidación de servicios de transporte
especial de personal.

---

## Sobre los datos

El conjunto de datos es **sintético** y se generó para este ejercicio académico. Sus registros no
provienen de una empresa ni permiten afirmar que sus frecuencias, magnitudes o resultados sean
representativos de una operación real. Las cifras sirven para demostrar el flujo técnico y las
validaciones descritas en estos entregables. Si se incorporan datos reales en un trabajo futuro,
deben revisarse sus permisos, finalidades y controles de protección aplicables.

> Este proyecto tiene fines exclusivamente académicos. No es un sistema en producción y sus cifras
> no deben usarse para decisiones operativas o comerciales.

---

## Requisitos

- **Python 3.10 o superior**
- Para el tablero: **Power BI Desktop** (Windows)

## Instalación

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Ejecución

```bash
# 1. Generar el conjunto de datos (opcional: ya viene generado en 00_DATOS/raw/)
python 00_DATOS/generador_datos.py

# 2. Ejecutar el pipeline ETL
python 04_PIPELINE.py
```

El pipeline lee de `00_DATOS/raw/`, escribe en `00_DATOS/limpio/` y deja la bitácora de la ejecución
en `00_DATOS/logs/pipeline.log`. No recibe argumentos ni depende de rutas absolutas.

Al terminar imprime el resultado de las nueve validaciones de integridad. Una validación con aviso
no detiene el proceso: queda registrada.

### Abrir el proyecto de tablero

1. Ejecutar `CONFIGURAR_DASHBOARD.ps1` una vez desde esta carpeta. El script ajusta la ruta del
   parámetro de datos a la ubicación local del proyecto.
2. Abrir `06_DASHBOARD.pbip` en Power BI Desktop.
3. En Power BI, seleccionar `Inicio → Actualizar`.

El tablero se entrega como proyecto **PBIP** editable y como archivo de Power BI Desktop **`06_DASHBOARD.pbix`**. Power BI Desktop es necesario para abrirlo, actualizar la ruta local y refrescar los datos. El PBIP queda como fuente editable del informe; el PBIX es la copia lista para abrir y presentar.

Para reconstruirlo desde cero, ver [`06_DASHBOARD_GUIA_CONSTRUCCION.md`](06_DASHBOARD_GUIA_CONSTRUCCION.md).

## Diseño visual

`05_DISENO.pdf` contiene el sistema visual, el mapa de los doce KPI, tres mockups de escritorio de
1440 × 900 px y la especificación de filtros e interacción. La carpeta `05_MOCKUPS_FIGMA_IMPORTABLE/`
incluye artboards vectoriales SVG y tokens de diseño para edición o importación en Figma. No contiene
un archivo nativo `.fig`.

---

## Estructura del proyecto

```
01_Proyecto_Tecnico/
├── 00_DATOS/
│   ├── generador_datos.py        Generación del conjunto sintético calibrado
│   ├── calibracion.json          Parámetros de calibración
│   ├── raw/                      Datos crudos — entrada del pipeline
│   │   ├── liquidaciones_cabecera.xlsx
│   │   ├── liquidaciones_items.csv
│   │   └── historial_estados.csv
│   ├── limpio/                   Datos limpios — salida del pipeline
│   │   ├── liquidaciones.csv
│   │   ├── items.csv
│   │   ├── tiempos_proceso.csv
│   │   ├── kpis_mensuales.csv
│   │   └── validaciones.csv
│   └── logs/pipeline.log         Bitácora de ejecuciones
│
├── 01_REQUISITOS.docx            E1 · Contexto, usuarios y preguntas de negocio
├── 02_EDA.ipynb                  E2 · Análisis exploratorio
├── 02_EDA.pdf                    E2 · Reporte visual
├── 03_KPIs.docx                  E3 · Especificación de indicadores
├── 03_KPIs.xlsx                  E3 · Catálogo y diccionario de datos
├── 04_PIPELINE.py                E4 · Proceso ETL ejecutable
├── 04_PIPELINE.ipynb             E4 · Cuaderno de ejemplos
├── 05_DISENO.pdf                 E5 · Sistema visual, mapa KPI y mockups de alta fidelidad (7 páginas)
├── 05_MOCKUPS_FIGMA_IMPORTABLE/  E5 · Tres artboards SVG editables y tokens de diseño
├── CONFIGURAR_DASHBOARD.ps1      Ajusta la ruta de datos después de extraer el ZIP
├── 06_DASHBOARD.pbip             E6 · Proyecto Power BI editable (PBIP)
├── 07_DOCUMENTACION.docx         E7 · Documentación técnica y guía de usuario
├── 07_PRESENTACION.pptx          E7 · Presentación ejecutiva final (13 diapositivas)
├── GUIÓN_VIDEO_5_MIN.md          E7 · Guion para preparar la grabación
└── README.md
```

---

## Arquitectura

```
00_DATOS/raw/  ──►  04_PIPELINE.py  ──►  00_DATOS/limpio/  ──►  06_DASHBOARD.pbip
  (crudo)            extract              (limpio)              (presentación)
                     transform
                     validate
                     load
```

Los datos se transforman en **un solo lugar**. El tablero no limpia ni corrige: consume lo que
recibe. Por eso cualquier cifra del tablero se puede rastrear hasta una línea del pipeline.

> El generador produce registros sintéticos y defectos de práctica para que el pipeline ejecute sus
> reglas de limpieza. No es una exportación de un sistema real.

---

## Alcance

| Elemento | Cantidad |
|----------|----------|
| Preguntas de negocio | 6 |
| Indicadores | 12 (7 primarios, 5 secundarios) |
| Visualizaciones en el reporte PDF de E2 | 8 |
| Páginas del tablero | 3 |
| Validaciones de integridad | 9 |
| Período cubierto | 24 meses (sep 2024 – ago 2026) |
| Liquidaciones | 134 |
| Servicios analizados | 4.448 |

### Las seis preguntas

1. ¿Cuánto se liquida y cuánto se factura por operadora y por mes, y cómo evoluciona?
2. ¿Cuánto tarda una liquidación en pasar de elaborada a facturada, y en qué punto se estanca?
3. ¿De qué se compone el ingreso: servicio base, recargos, transporte adicional y pernoctes?
4. ¿Qué vehículos y recorridos concentran la facturación y cuáles están subutilizados?
5. ¿Cuánto valor se pierde en descuentos y anulaciones, y por qué motivo?
6. ¿Qué participación tienen los terceros frente a la flota propia?

---

## Hallazgo principal

**El cuello de botella del proceso está en la aprobación, no en la facturación.**

| Etapa | Días promedio |
|-------|---------------|
| Borrador → Liquidada | 3,1 |
| **Liquidada → Aprobada** | **10,8** |
| Aprobada → Facturada | 4,2 |
| **Ciclo completo** | **18,0** |

La etapa de aprobación tarda 2,6 veces más que la siguiente y tiene la dispersión más amplia. Es
ingreso facturable detenido, y es sobre lo que se puede actuar.

---

## Componente analítico

Detección de valores atípicos en los ítems de liquidación mediante el **criterio de rango
intercuartílico**, aplicado por tipo de tarifa. Marca automáticamente las líneas cuyo valor o
cantidad se sale del comportamiento esperado para su tipo de servicio, antes de que la liquidación
se apruebe y se facture.

Sobre 4.448 servicios se marcaron 122 registros (2,7%), con valores entre 9 y 18 veces la tarifa
mediana de su propio tipo. **Los registros se marcan, no se eliminan**: borrarlos escondería un
problema operativo real.

Se eligió un método estadístico explicable a propósito. En un proceso que termina en una factura,
poder justificar por qué se marcó un registro importa más que la sofisticación del método.

---

## Stack

| Capa | Herramienta |
|------|-------------|
| Origen | Excel · CSV |
| Procesamiento | Python · Pandas · NumPy |
| Análisis | Jupyter · Matplotlib · Seaborn |
| Presentación | Power BI |

---

## Licencia y uso

Trabajo académico presentado como entregable de opción de grado. El código puede reutilizarse con
fines educativos. Los datos son sintéticos y no representan información de ninguna organización real.

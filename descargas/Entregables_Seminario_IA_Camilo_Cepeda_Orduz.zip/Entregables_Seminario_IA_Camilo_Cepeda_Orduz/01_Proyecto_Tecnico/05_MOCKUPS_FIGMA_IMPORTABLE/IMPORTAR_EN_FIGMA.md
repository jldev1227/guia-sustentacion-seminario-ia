# Mockups vectoriales importables en Figma

Este paquete contiene tres artboards de escritorio de 1440 × 900 px, fuente SVG editable:

- `01_vision_ejecutiva.svg`
- `02_detalle_operacional.svg`
- `03_tiempos_comparativos.svg`

Para incorporarlos a un archivo de Figma, crea un diseño nuevo e importa/arrastra cada SVG al lienzo. Cada página conserva las formas y textos vectoriales. El PDF `../05_DISENO.pdf` reúne el sistema visual, el mapa de los 12 KPI, las tres pantallas de alta fidelidad y las reglas de interacción.

Los valores visibles describen únicamente el dataset sintético incluido en el proyecto. No representan una empresa real.

Este paquete es una alternativa local basada en SVG/PDF; no contiene un archivo nativo `.fig` ni fue cargado a una cuenta de Figma.

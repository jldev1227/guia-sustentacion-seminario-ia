# Entregables del Seminario de Inteligencia Artificial

**Autor:** Camilo Cepeda Orduz  
**Institución:** Fundación de Educación Superior San José  
**Período:** 2026-2

## Contenido

- `00_Ensayo/`: ensayo APA editable en DOCX y versión PDF.
- `01_Proyecto_Tecnico/`: entregables E1–E7, datos de práctica, pipeline y proyecto Power BI.

La [guía web de sustentación](https://jldev1227.github.io/guia-sustentacion-seminario-ia/)
incluye el guion interactivo y el enlace a esta descarga.

## Antes de abrir el tablero

El tablero se entrega como proyecto Power BI PBIP, no como archivo PBIX. En Windows, ejecute
`CONFIGURAR_DASHBOARD.ps1` desde `01_Proyecto_Tecnico/`, abra `06_DASHBOARD.pbip` en Power BI
Desktop y actualice el modelo. El proyecto conserva tres páginas interactivas.

## Alcance de la evidencia

Los registros y resultados son sintéticos y se usan con fines académicos. No describen ni estiman
una empresa real. E7 incluye la presentación y el guion cronometrado solicitado para preparar el
video; el paquete no contiene una grabación MP4.

# Entregables del Seminario de Inteligencia Artificial

**Autor:** Camilo Cepeda Orduz  
**Institución:** Fundación de Educación Superior San José  
**Período:** 2026-2

## Contenido

- `00_Ensayo/`: ensayo APA editable en DOCX y versión PDF.
- `01_Proyecto_Tecnico/`: E1–E7, datos de práctica, ETL y proyecto Power BI.
- `01_Proyecto_Tecnico/05_MOCKUPS_FIGMA_IMPORTABLE/`: tres mockups SVG vectoriales, tokens y guía para importarlos a Figma. El PDF de siete páginas acompaña el diseño. El paquete aún no incluye archivo nativo `.fig`.

## Abrir el tablero

Se incluyen el proyecto editable `06_DASHBOARD.pbip` y el archivo `06_DASHBOARD.pbix`, con tres páginas. Para abrir el PBIP, ejecute `CONFIGURAR_DASHBOARD.ps1` desde `01_Proyecto_Tecnico/`, abra `06_DASHBOARD.pbip` en Power BI Desktop y actualice el modelo. El PBIX se puede abrir directamente en Power BI Desktop.

## Alcance de la evidencia

Los registros son sintéticos y se usan con fines académicos. No describen ni estiman una empresa real. E7 incluye la presentación y el guion de apoyo para el video de cinco minutos; el ZIP no contiene la grabación del tutorial.